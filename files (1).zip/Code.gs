// ชื่อชีตต้องตรงกับไฟล์ของคุณ: Transactions / Categories
// คอลัมน์ Transactions: A วันที่ | B ประเภท | C หมวดหมู่ | D จำนวนเงิน | E รายละเอียด | F เดือน-ปี

function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('บันทึกรายรับรายจ่าย')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function getData() {
  const ss = SpreadsheetApp.getActive();
  const tz = ss.getSpreadsheetTimeZone();
  const rows = ss.getSheetByName('Transactions').getDataRange().getValues();
  const tx = [];
  for (let i = 1; i < rows.length; i++) {
    const r = rows[i];
    const amt = Number(String(r[3]).replace(/,/g, ''));
    const date = normDate(r[0], tz);
    if (!date || isNaN(amt) || r[3] === '') continue;
    tx.push({
      row: i + 1,
      date: date,
      type: String(r[1]).indexOf('รับ') > -1 ? 'in' : 'ex',
      cat: String(r[2]).trim(),
      amt: amt,
      note: r[4] || ''
    });
  }
  const c = ss.getSheetByName('Categories').getDataRange().getValues().slice(1);
  const cats = {
    in: c.map(r => r[0]).filter(String),
    ex: c.map(r => r[1]).filter(String)
  };
  return { tx: tx, cats: cats };
}

function addTx(o) {
  const ss = SpreadsheetApp.getActive();
  const tz = ss.getSpreadsheetTimeZone();
  const d = Utilities.parseDate(o.date, tz, 'yyyy-MM-dd');
  ss.getSheetByName('Transactions').appendRow([
    d,
    o.type === 'in' ? 'รายรับ' : 'รายจ่าย',
    o.cat,
    Number(o.amt),
    o.note || '',
    Utilities.formatDate(d, tz, 'yyyy-MM')
  ]);
  return getData();
}

function deleteTx(row) {
  SpreadsheetApp.getActive().getSheetByName('Transactions').deleteRow(Number(row));
  return getData();
}

// แปลงวันที่ทุกรูปแบบ (Date, 2026-10-01, 01/10/2026, ปี พ.ศ.) เป็น yyyy-MM-dd
function normDate(v, tz) {
  if (v === '' || v === null) return '';
  let y, m, d;
  if (v instanceof Date) {
    [y, m, d] = Utilities.formatDate(v, tz, 'yyyy-MM-dd').split('-').map(Number);
  } else {
    const s = String(v).trim();
    let a = s.match(/^(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})/);
    let b = s.match(/^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})/);
    if (a) { y = +a[1]; m = +a[2]; d = +a[3]; }
    else if (b) { d = +b[1]; m = +b[2]; y = +b[3]; }
    else return '';
  }
  if (y > 2400) y -= 543;
  const p = n => ('0' + n).slice(-2);
  return y + '-' + p(m) + '-' + p(d);
}
